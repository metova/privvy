# Template
Copy this folder to /Applications/Android Studio/Contents/plugins/android/lib/templates/other/
Restart Android Studio

(Also works with IntelliJ)
